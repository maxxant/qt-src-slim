<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<dependencies>
<dependency catalog="qtbase_ru"/>
<dependency catalog="qtscript_ru"/>
<dependency catalog="qtmultimedia_ru"/>
<dependency catalog="qtxmlpatterns_ru"/>
</dependencies>
</TS>
