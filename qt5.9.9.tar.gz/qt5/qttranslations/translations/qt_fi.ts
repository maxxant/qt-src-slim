<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fi">
    <dependencies>
        <dependency catalog="qtbase_fi"/>
        <dependency catalog="qtscript_fi"/>
        <dependency catalog="qtquick1_fi"/>
        <dependency catalog="qtmultimedia_fi"/>
    </dependencies>
</TS>
